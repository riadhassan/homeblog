---
title: "Second snippet"
---

This content is in `snippets/second/index.md`

```sh
ls -la
```
